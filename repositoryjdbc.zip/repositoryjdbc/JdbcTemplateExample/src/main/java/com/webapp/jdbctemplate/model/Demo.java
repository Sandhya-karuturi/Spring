/**
 * 
 */
package com.webapp.jdbctemplate.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Happy
 *
 */
//@Getter
//@Setter
//@ToString
//@AllArgsConstructor
//@NoArgsConstructor
public class Demo {

	private int id;
	private String string;
	
	
	/**
	 * 
	 */
	public Demo() {
		
	}
	/**
	 * @param id
	 * @param string
	 */
	public Demo(int id, String string) {
	
		this.id = id;
		this.string = string;
	}
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the string
	 */
	public String getString() {
		return string;
	}
	/**
	 * @param string the string to set
	 */
	public void setString(String string) {
		this.string = string;
	}
	@Override
	public String toString() {
		return "Demo [id=" + id + ", string=" + string + "]";
	}	
	
	
}
