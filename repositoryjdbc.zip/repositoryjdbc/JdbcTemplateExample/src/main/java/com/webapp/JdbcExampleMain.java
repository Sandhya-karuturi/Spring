/**
 * 
 */
package com.webapp;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.webapp.jdbctemplate.ApplicationConfig;
import com.webapp.jdbctemplate.dao.impl.DemoDaoImpl;
import com.webapp.jdbctemplate.model.Demo;

/**
 * @author Happy
 *
 */
public class JdbcExampleMain {

	
	public static void main(String[] args) {
		
		AbstractApplicationContext appContext = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		DemoDaoImpl daoImpl = (DemoDaoImpl) appContext.getBean("demoDaoImpl");
		Demo demoInsert = new Demo(11,"india");
		Demo demoUpdate = new Demo(2, "sandya");
		daoImpl.addDemo(demoInsert);
		daoImpl.editDemo(demoUpdate, demoUpdate.getId());
			
	}
}
