/**
 * 
 */
package com.webapp.jdbctemplate.dao.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.webapp.jdbctemplate.dao.DemoDao;
import com.webapp.jdbctemplate.model.Demo;

/**
 * @author Happy
 *
 */
@Repository
@Qualifier("demoDaoImpl")
public class DemoDaoImpl implements DemoDao{

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	private DemoDao demoDao;
	
	private final String insertQuery = "INSERT INTO Demo VALUES(?,?)";
	private final String updatetQuery = "UPDATE demo SET string=? WHERE id=?";
	private final String fetchById = "SELECT * FROM demo WHERE id=?";
	private final String fetchByString = "SELECT * FROM demo WHERE string=?";
	@Override
	public void addDemo(Demo demo) {
	
		jdbcTemplate.update(insertQuery,demo.getId(), demo.getString());
	}

	@Override
	public void editDemo(Demo demo, int demoId) {
		
		jdbcTemplate.update(updatetQuery,demo.getString(), demoId);
	}
}
