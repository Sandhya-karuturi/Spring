/**
 * 
 */
package com.webapp.jdbctemplate.dao;

import com.webapp.jdbctemplate.model.Demo;

/**
 * @author Happy
 *
 */
public interface DemoDao {

	public void addDemo(Demo demo);
	public void editDemo(Demo demo, int demoId);
}
