/**
 * 
 */
package com.demo.spring.mvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author Happy
 *
 */
@Controller
public class SpringExampleController {

	@GetMapping("/registration")
	public String showHomePage() {
		
		return "registration";
	}
	
	@PostMapping("/registerme")
	public String registerMe(@RequestParam("fn") String firstName, @RequestParam("ln") String lastName, 
			@RequestParam("email") String email, Model model) {
		
		System.out.println(" firstname  "+firstName+",  last name "+"  email  "+email);
		model.addAttribute("firstname", firstName);
		model.addAttribute("lastname", lastName);
		return "home";
	}
}
